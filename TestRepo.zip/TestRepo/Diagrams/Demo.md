You can include your diagram using an image reference:

![This is my diagram](Simple-Diagram.png)


test edit

```plantuml
@startuml asc
Bob->Alice : hellss
Bob->Alice : hel
@enduml
```